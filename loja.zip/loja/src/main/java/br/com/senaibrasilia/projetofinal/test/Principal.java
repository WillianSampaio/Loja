package br.com.senaibrasilia.projetofinal.test;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.senaibrasilia.projeto.util.JPAUtil;
import br.com.senaibrasilia.projetofinal.dao.CategoriaDAO;
import br.com.senaibrasilia.projetofinal.dao.ProdutoDAO;
import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;

public class Principal {
	private static void cadastrarProduto() {
		Categoria vestuario = new Categoria("VESTUARIO");
		Produto roupa1 = new Produto("Cal�a Feminina", "Sarja Wide",new BigDecimal("109"),vestuario);
		Produto roupa2 = new Produto("Blusa Regata Feminina", "Textura Ombro",new BigDecimal("29"),vestuario);
		Produto roupa3 = new Produto("Cal�a Jeans", "Super Slim",new BigDecimal("529"),vestuario);
		Produto roupa4 = new Produto("Bermuda Chino", "El�stico Solid ",new BigDecimal("329"),vestuario);
		
		
		Categoria celulares = new Categoria("CELULARES");
		Produto celular1 = new Produto("Xiaomi Redmi", "Xiome",new BigDecimal("800"),celulares);
		Produto celular2 = new Produto("iPhone 13", "Apple",new BigDecimal("5000"),celulares);
		Produto celular3 = new Produto("Galaxy S22 Ultra 5G", "Samsung",new BigDecimal("7300"),celulares);
		Produto celular4 = new Produto("Moto G8 Power", "Motorola",new BigDecimal("5000"),celulares);


		
		
		EntityManager conect = JPAUtil.getEntityManager();		
		ProdutoDAO produtoDAO = new ProdutoDAO(conect);		
		CategoriaDAO categoriaDAO = new CategoriaDAO(conect);
		
		conect.getTransaction().begin();		
		categoriaDAO.cadastrar(celulares);
		produtoDAO.cadastrar(celular1);
		produtoDAO.cadastrar(celular2);
		produtoDAO.cadastrar(celular3);
		produtoDAO.cadastrar(celular4);
		
		categoriaDAO.cadastrar(vestuario);
		produtoDAO.cadastrar(roupa1);
		produtoDAO.cadastrar(roupa2);
		produtoDAO.cadastrar(roupa3);
		produtoDAO.cadastrar(roupa4);
		
		
		conect.getTransaction().commit();
		conect.close();
		
	}
	public static void main(String[] args) {

		cadastrarProduto();
		//Produto produto = new Produto("Mouse","Mouse Dell Optiocal",new BigDecimal("100"));
		//Categoria c = new Categoria();
		//c.setNome("Eletr�nica");
		
		EntityManager conect = JPAUtil.getEntityManager();
		ProdutoDAO produtoDAO = new ProdutoDAO(conect);
		
		//Produto p = produtoDAO.pesquisarPorCodigo(1l);
		//System.out.println(p.getPreco());
		
		List<Produto> celular = produtoDAO.pesquisaPorNomeDaCategoria("CELULARES");
		celular.forEach(p2 -> System.out.println("\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
		
		List<Produto> roupa = produtoDAO.pesquisaPorNomeDaCategoria("VESTUARIO");
		roupa.forEach(p2 -> System.out.println("\nProduto: "+p2.getNome()+"\nPre�o: "+p2.getPreco()));
		
		
		//BigDecimal precoDoProduto = produtoDAO.pesquisaPrecoDoProdutoComNome("Xioami Redmi");
		
		//System.out.println("Preco do Produto: " + precoDoProduto);
		//System.out.println(p);
		
		
		
		
		
		//EntityManager - Roberto Carlos do JPA

		//Estado New (FCC)
//		
//		

//
//		//Realizar a conex�o
//		EntityManagerFactory factory = Persistence.createEntityManagerFactory("loja");

		//O CARA � agora o objeto "em"
//		EntityManager em = factory.createEntityManager();
//
//
//					//Entra no estado gerenciado
//
//		em.persist(produto);					//Salva no Banco
//		
//		em.persist(c);
//
//		em.getTransaction().commit();			//Fecha



//		System.out.println(produto.getId());
//		System.out.println(produto.getNome());
//		System.out.println(produto.getDescricao());
//		System.out.println(produto.getPreco());
//		System.out.println(produto);
		
		
		
		
	}

}
